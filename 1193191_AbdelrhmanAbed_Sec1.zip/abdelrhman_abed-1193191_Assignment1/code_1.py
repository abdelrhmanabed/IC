import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.metrics import mean_squared_error, peak_signal_noise_ratio
import time
import pandas as pd

def load_image(choice):
    if choice == 1:
        image_path = 'low.png'
    elif choice == 2:
        image_path = 'middle.jpg'
    elif choice == 3:
        image_path = 'high.jpg'
    else:
        raise ValueError("Invalid choice! Please enter 1, 2, or 3.")
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Image at {image_path} could not be loaded.")
    return image

print("Choose an image to load:")
print("1. Picture with low details")
print("2. Picture with middle details")
print("3. Picture with high details")

choice = int(input("Enter the number of your choice: "))

try:
    original_image = load_image(choice)
except (ValueError, FileNotFoundError) as e:
    print(e)
    exit()

print("Choose the Gaussian noise intensity level:")
print("1. Low intensity")
print("2. Medium intensity")
print("3. High intensity")

gaussian_choice = int(input("Enter the number of your choice: "))

if gaussian_choice == 1:
    gaussian_var = 0.1
elif gaussian_choice == 2:
    gaussian_var = 0.5
elif gaussian_choice == 3:
    gaussian_var = 1.2
else:
    print("Invalid intensity level! Please enter 1, 2, or 3.")
    exit()

gaussian_noise_levels = {1: "Low", 2: "Medium", 3: "High"}
gaussian_noise_level_label = gaussian_noise_levels.get(gaussian_choice, "Unknown")

print("Choose the Salt-and-Pepper noise intensity level:")
print("1. Low intensity")
print("2. Medium intensity")
print("3. High intensity")

sp_choice = int(input("Enter the number of your choice: "))

if sp_choice == 1:
    sp_prob = 0.02
elif sp_choice == 2:
    sp_prob = 0.05
elif sp_choice == 3:
    sp_prob = 0.1
else:
    print("Invalid intensity level! Please enter 1, 2, or 3.")
    exit()

sp_noise_levels = {1: "Low", 2: "Medium", 3: "High"}
sp_noise_level_label = sp_noise_levels.get(sp_choice, "Unknown")

def add_gaussian_noise(img, mean=0, var=0.5):
    img = img.astype(np.float32)
    sigma = var ** 0.5
    gaussian = np.random.normal(mean, sigma, img.shape)
    noisy_image = img + (gaussian * 255)
    return np.clip(noisy_image, 0, 255).astype(np.uint8)

def add_salt_pepper_noise(img, prob=0.05):
    noisy_image = np.copy(img)
    salt_pepper = np.random.rand(*img.shape)
    noisy_image[salt_pepper < prob / 2] = 0
    noisy_image[salt_pepper > 1 - prob / 2] = 255
    return noisy_image

gaussian_noisy_image = add_gaussian_noise(original_image, var=gaussian_var)
salt_pepper_noisy_image = add_salt_pepper_noise(original_image, prob=sp_prob)

def plot_original_and_noisy_images(original, gaussian_noise, sp_noise):
    plt.figure(figsize=(18, 6))
    plt.subplot(1, 3, 1)
    plt.imshow(original, cmap='gray')
    plt.title('Original Image')
    plt.axis('off')
    plt.subplot(1, 3, 2)
    plt.imshow(gaussian_noise, cmap='gray')
    plt.title(f'Gaussian Noise ({gaussian_noise_level_label})')
    plt.axis('off')
    plt.subplot(1, 3, 3)
    plt.imshow(sp_noise, cmap='gray')
    plt.title(f'Salt-and-Pepper Noise ({sp_noise_level_label})')
    plt.axis('off')
    plt.tight_layout()
    plt.show()

plot_original_and_noisy_images(original_image, gaussian_noisy_image, salt_pepper_noisy_image)

def apply_filters_and_visualize_with_edges(img, noise_type, noise_level_label):
    kernel_sizes = [3, 5, 7]
    filters = ['Box', 'Gaussian', 'Median', 'Bilateral', 'Adaptive Mean', 'Adaptive Median']
    results = []
    edges_original = cv2.Canny(original_image, 100, 200)
    for k in kernel_sizes:
        for filter_name in filters:
            start_time = time.time()
            if filter_name == 'Box':
                filtered_img = cv2.blur(img, (k, k))
            elif filter_name == 'Gaussian':
                filtered_img = cv2.GaussianBlur(img, (k, k), 0)
            elif filter_name == 'Median':
                filtered_img = cv2.medianBlur(img, k)
            elif filter_name == 'Bilateral':
                filtered_img = cv2.bilateralFilter(img, k, 75, 75)
            elif filter_name == 'Adaptive Mean':
                padded_img = cv2.copyMakeBorder(img, k//2, k//2, k//2, k//2, cv2.BORDER_REFLECT)
                filtered_img = np.zeros_like(img)
                for x in range(img.shape[0]):
                    for y in range(img.shape[1]):
                        local_patch = padded_img[x:x+k, y:y+k]
                        filtered_img[x, y] = np.mean(local_patch)
            elif filter_name == 'Adaptive Median':
                padded_img = cv2.copyMakeBorder(img, k//2, k//2, k//2, k//2, cv2.BORDER_REFLECT)
                filtered_img = np.zeros_like(img)
                for x in range(img.shape[0]):
                    for y in range(img.shape[1]):
                        local_patch = padded_img[x:x+k, y:y+k].flatten()
                        filtered_img[x, y] = np.median(local_patch)
            end_time = time.time()
            elapsed_time = end_time - start_time
            mse = mean_squared_error(original_image, filtered_img)
            psnr = peak_signal_noise_ratio(original_image, filtered_img, data_range=255)
            edges_filtered = cv2.Canny(filtered_img, 100, 200)
            total_original_edges = np.sum(edges_original > 0)
            differing_edges = np.sum(edges_original != edges_filtered)
            edge_preservation = max(0, 1 - (differing_edges / total_original_edges))
            results.append({
                'Noise_Type': noise_type,
                'Filter': filter_name,
                'Kernel_Size': k,
                'Noise Level': noise_level_label,
                'MSE': mse,
                'PSNR': psnr,
                'Time (s)': elapsed_time,
                'Edge Preservation': edge_preservation
            })
            plt.figure(figsize=(18, 8))
            plt.suptitle(f"{noise_type} ({noise_level_label}) - {filter_name} Filter (Kernel Size {k})", fontsize=16, weight='bold')
            plt.subplot(2, 3, 1)
            plt.imshow(original_image, cmap='gray')
            plt.axis('off')
            plt.title("Original Image", fontsize=12)
            plt.subplot(2, 3, 2)
            plt.imshow(img, cmap='gray')
            plt.axis('off')
            plt.title(f"{noise_type} ({noise_level_label})", fontsize=12)
            plt.subplot(2, 3, 3)
            plt.imshow(edges_original, cmap='gray')
            plt.axis('off')
            plt.title("Original Edge Map", fontsize=12)
            plt.subplot(2, 3, 4)
            plt.imshow(filtered_img, cmap='gray')
            plt.axis('off')
            plt.title(f"{filter_name} Filter\nMSE: {mse:.2f}, PSNR: {psnr:.2f}, Time: {elapsed_time:.2f}", fontsize=10)
            plt.subplot(2, 3, 5)
            plt.imshow(edges_filtered, cmap='gray')
            plt.axis('off')
            plt.title(f"Filtered Edge Map\nEdge Preservation: {edge_preservation:.2f}", fontsize=10)
            plt.tight_layout()
            plt.subplots_adjust(top=0.88)
            plt.show()
    return results

results_gaussian = apply_filters_and_visualize_with_edges(gaussian_noisy_image, 'Gaussian Noise', gaussian_noise_level_label)
results_salt_pepper = apply_filters_and_visualize_with_edges(salt_pepper_noisy_image, 'Salt-and-Pepper Noise', sp_noise_level_label)
all_results = results_gaussian + results_salt_pepper
output_file = "results.csv"
df_results = pd.DataFrame(all_results)
column_order = ['Noise_Type', 'Filter', 'Kernel_Size', 'Noise Level', 'MSE', 'PSNR', 'Time (s)', 'Edge Preservation']
df_results = df_results[column_order]
df_results.to_csv(output_file, index=False)
print(f"\n results  {output_file}.")
